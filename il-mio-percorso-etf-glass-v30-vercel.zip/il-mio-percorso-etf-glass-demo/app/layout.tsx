import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Il Mio Percorso ETF | Glass Dashboard', description: 'Dashboard dimostrativa per monitorare portafoglio ETF, PAC e investimenti.' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="it"><body>{children}</body></html>; }
