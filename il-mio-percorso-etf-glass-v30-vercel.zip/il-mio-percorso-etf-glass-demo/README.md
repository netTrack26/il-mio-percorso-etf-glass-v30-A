# Il Mio Percorso ETF — Glass Dashboard V30 (Demo Vercel)

Questa è una versione autonoma, Vercel-first e senza dipendenze da Supabase o Cloudflare. Serve per approvare interfaccia, navigazione e flussi prima della fase database.

## Avvio locale

```bash
npm install
npm run dev
```

Apri http://localhost:3000.

## Deploy su Vercel

1. Carica questo archivio su un repository GitHub nuovo o dedicato.
2. In Vercel scegli **Add New → Project** e importa il repository.
3. Framework: Next.js. Root Directory: `./`.
4. Non servono variabili d'ambiente per questa demo.
5. Premi Deploy.

## Cosa include

- UI glassmorphism ispirata al riferimento: sidebar compatta/espandibile, top navigation, pannelli traslucidi, grafici, KPI e accenti lime.
- Dashboard, portafoglio, esplora ETF, watchlist, PAC, analisi e transazioni.
- Registrazione acquisti demo e calcolo di quantità, costo medio, controvalore e commissione.
- Salvataggio demo nel localStorage del browser.
- Layout responsive desktop e smartphone.

## Limiti intenzionali della demo

- Tutti i prezzi e i valori iniziali sono dimostrativi e non sono quotazioni live.
- I dati demo restano nel browser che li ha creati; non c'è un database condiviso.
- Non vengono inviati ordini a broker e il PAC è solo illustrativo.
- Autenticazione, database, API quotazioni, import CSV persistente e sincronizzazione saranno aggiunti solo dopo l'approvazione della UI.
